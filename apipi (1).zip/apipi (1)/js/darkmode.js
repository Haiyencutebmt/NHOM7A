const body = document.body;
const lightModeButton = document.getElementById("light-mode");
const darkModeButton = document.getElementById("dark-mode");

// Kiểm tra chế độ hiện tại từ localStorage
if (localStorage.getItem("theme") === "dark") {
  body.classList.add("dark-mode");
}

// Sự kiện nhấp vào "Chế độ sáng"
lightModeButton.addEventListener("click", () => {
  body.classList.remove("dark-mode");
  localStorage.setItem("theme", "light");
});

// Sự kiện nhấp vào "Chế độ tối"
darkModeButton.addEventListener("click", () => {
  body.classList.add("dark-mode");
  localStorage.setItem("theme", "dark");
});
