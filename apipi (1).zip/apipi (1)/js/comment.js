function addComment() {
    const commentInput = document.getElementById('comment-input');
    const commentsContainer = document.getElementById('comments-container');
    const commentText = commentInput.value.trim();

    if (commentText) {
        const newComment = createCommentElement(commentText);
        commentsContainer.appendChild(newComment);
        saveComment(commentText);
        commentInput.value = '';
    } else {
        alert('Vui lòng nhập bình luận của bạn.');
    }

    return false;
}

function createCommentElement(commentText) {
    const commentElement = document.createElement('div');
    commentElement.className = 'comment';
    commentElement.textContent = commentText;

    // Create a delete button for each comment
    const deleteButton = document.createElement('button');
    deleteButton.textContent = 'Xóa';
    deleteButton.onclick = function() {
        deleteComment(commentText);
    };

    commentElement.appendChild(deleteButton);
    return commentElement;
}

function saveComment(comment) {
    let comments = JSON.parse(localStorage.getItem('comments')) || [];
    comments.push(comment);
    localStorage.setItem('comments', JSON.stringify(comments));
    displayComments();
}

function deleteComment(commentToDelete) {
    let comments = JSON.parse(localStorage.getItem('comments')) || [];
    comments = comments.filter(comment => comment !== commentToDelete);
    localStorage.setItem('comments', JSON.stringify(comments));
    displayComments();
}

function displayComments() {
    const commentsContainer = document.getElementById('comments-container');
    commentsContainer.innerHTML = ''; // Clear existing comments
    let comments = JSON.parse(localStorage.getItem('comments')) || [];
    comments.forEach(comment => {
        const commentElement = createCommentElement(comment);
        commentsContainer.appendChild(commentElement);
    });
}

// Load comments from local storage when the page is loaded
window.onload = function() {
    displayComments();
};